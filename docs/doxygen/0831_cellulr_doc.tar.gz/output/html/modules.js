var modules =
[
    [ "Cellular Parameter structures", "group__cellular__datatypes__paramstructs.html", "group__cellular__datatypes__paramstructs" ],
    [ "Cellular Handles", "group__cellular__datatypes__handles.html", "group__cellular__datatypes__handles" ],
    [ "Cellular Function pointer types", "group__cellular__datatypes__functionpointers.html", "group__cellular__datatypes__functionpointers" ],
    [ "Cellular Enumerated types", "group__cellular__datatypes__enums.html", "group__cellular__datatypes__enums" ],
    [ "Cellular_common Parameter structures", "group__cellular__common__datatypes__paramstructs.html", "group__cellular__common__datatypes__paramstructs" ],
    [ "Cellular_common Function pointer types", "group__cellular__common__datatypes__functionpointers.html", "group__cellular__common__datatypes__functionpointers" ],
    [ "Cellular_common Enumerated types", "group__cellular__common__datatypes__enums.html", "group__cellular__common__datatypes__enums" ]
];