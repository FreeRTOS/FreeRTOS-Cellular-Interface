var group__cellular__datatypes__functionpointers =
[
    [ "CellularATCommandResponseReceivedCallback_t", "group__cellular__datatypes__functionpointers.html#gaf7edbf808ad1b5cc1f148e87d074634a", null ],
    [ "CellularUrcNetworkRegistrationCallback_t", "group__cellular__datatypes__functionpointers.html#gad1a22268b06f460997793941941ca3bb", null ],
    [ "CellularUrcPdnEventCallback_t", "group__cellular__datatypes__functionpointers.html#gac303171e7aafe464487f0c299cac7ec4", null ],
    [ "CellularUrcSignalStrengthChangedCallback_t", "group__cellular__datatypes__functionpointers.html#ga6a1a56e15ffa47adf112ba72c77227cd", null ],
    [ "CellularUrcGenericCallback_t", "group__cellular__datatypes__functionpointers.html#gafa99a26c969344ab121ab5692a64abfb", null ],
    [ "CellularModemEventCallback_t", "group__cellular__datatypes__functionpointers.html#ga5d57242d94fe9f1bbd13ab55c5ee56f5", null ],
    [ "CellularSocketOpenCallback_t", "group__cellular__datatypes__functionpointers.html#gaeea01ac3c14d011d6fbcad4c7da59bdb", null ],
    [ "CellularSocketDataReadyCallback_t", "group__cellular__datatypes__functionpointers.html#gae2d9c4772620983b497dc0762ea97a77", null ],
    [ "CellularSocketClosedCallback_t", "group__cellular__datatypes__functionpointers.html#gabb2713e4b1f3e2077680b7c8c82c274a", null ]
];