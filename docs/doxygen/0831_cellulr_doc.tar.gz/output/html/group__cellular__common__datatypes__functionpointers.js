var group__cellular__common__datatypes__functionpointers =
[
    [ "CellularAtParseTokenHandler_t", "group__cellular__common__datatypes__functionpointers.html#ga263880a7073eb336d37873d6f859b757", null ],
    [ "CellularATCommandDataPrefixCallback_t", "group__cellular__common__datatypes__functionpointers.html#gac9ed75355d4bf632ec7e170066461fb6", null ],
    [ "CellularATCommandDataSendPrefixCallback_t", "group__cellular__common__datatypes__functionpointers.html#gada9a53c3c173e90c3829ecdeb67de276", null ]
];