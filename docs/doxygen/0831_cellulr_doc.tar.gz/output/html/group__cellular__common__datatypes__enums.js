var group__cellular__common__datatypes__enums =
[
    [ "CellularSocketState_t", "group__cellular__common__datatypes__enums.html#ga5452a7d76c6f3fe297bea080bfb18b9f", [
      [ "SOCKETSTATE_ALLOCATED", "group__cellular__common__datatypes__enums.html#gga5452a7d76c6f3fe297bea080bfb18b9fadb6f0c2359e1183751b74e5aa74f68b5", null ],
      [ "SOCKETSTATE_CONNECTING", "group__cellular__common__datatypes__enums.html#gga5452a7d76c6f3fe297bea080bfb18b9fa3fda0e54a2dd3b85fdcc156264e4d44f", null ],
      [ "SOCKETSTATE_CONNECTED", "group__cellular__common__datatypes__enums.html#gga5452a7d76c6f3fe297bea080bfb18b9fa8e58311ac8755d916ff1c788594a0ca3", null ],
      [ "SOCKETSTATE_DISCONNECTED", "group__cellular__common__datatypes__enums.html#gga5452a7d76c6f3fe297bea080bfb18b9fa412aaae49eeed481cc4d467215ea1114", null ]
    ] ]
];