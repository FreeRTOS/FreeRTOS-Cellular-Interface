var struct_cellular_comm_interface__t =
[
    [ "open", "struct_cellular_comm_interface__t.html#af5413e6ba84c706591c7ee04e94a7b17", null ],
    [ "send", "struct_cellular_comm_interface__t.html#a695354e1be93901de855fcfd405130ae", null ],
    [ "recv", "struct_cellular_comm_interface__t.html#a3b0c651ca2a88baaaa9d7bd9fd0e4ab5", null ],
    [ "close", "struct_cellular_comm_interface__t.html#ad6aa698a3c69c3d219d856db1e57c228", null ]
];