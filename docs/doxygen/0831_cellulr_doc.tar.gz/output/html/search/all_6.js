var searchData=
[
  ['firmwareversion_0',['firmwareVersion',['../struct_cellular_modem_info__t.html#a2ee0ff347ab0d617538cb6aab3dd4325',1,'CellularModemInfo_t']]],
  ['functions_1',['Functions',['../cellular_common_functions.html',1,'cellular_porting_module_guide'],['../cellular_functions.html',1,'(Global Namespace)']]]
];
