var searchData=
[
  ['design_0',['Design',['../cellular_design.html',1,'']]]
];
