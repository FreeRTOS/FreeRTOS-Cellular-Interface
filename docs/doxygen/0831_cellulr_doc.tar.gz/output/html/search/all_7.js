var searchData=
[
  ['gprsreadytimer_0',['gprsReadyTimer',['../struct_cellular_psm_settings__t.html#a95f527ef459965d882ecb25e60716ff5',1,'CellularPsmSettings_t']]]
];
