var searchData=
[
  ['year_0',['year',['../struct_cellular_time__t.html#ac5179e1cc8525ac56829a0d7b1301209',1,'CellularTime_t']]]
];
