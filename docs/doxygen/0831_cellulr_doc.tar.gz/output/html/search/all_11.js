var searchData=
[
  ['timezone_0',['timeZone',['../struct_cellular_time__t.html#acca5feafd3b070f04b1c4fbcbe82da02',1,'CellularTime_t']]]
];
