var searchData=
[
  ['cellular_20common_20apis_0',['Cellular common APIs',['../cellular_common__a_p_is.html',1,'porting_cellular_module']]],
  ['cellular_20common_20urc_20handlers_1',['Cellular common URC handlers',['../cellular_common__u_r_c_handlers.html',1,'porting_cellular_module']]],
  ['cellular_5fmodule_2',['cellular_module',['../cellular_module.html',1,'porting_cellular_module']]],
  ['cellular_5fmodule_5fapi_3',['cellular_module_api',['../cellular_module_api.html',1,'porting_cellular_module']]],
  ['cellular_5fmodule_5furc_5fhandler_4',['cellular_module_urc_handler',['../cellular_module_urc_handler.html',1,'porting_cellular_module']]],
  ['configurations_5',['Configurations',['../cellular_config.html',1,'']]]
];
