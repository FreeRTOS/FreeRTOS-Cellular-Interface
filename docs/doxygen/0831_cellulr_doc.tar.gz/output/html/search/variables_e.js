var searchData=
[
  ['rat_0',['rat',['../struct_cellular_service_status__t.html#a2d289ac8453a0b16f25a640a23a16b37',1,'CellularServiceStatus_t::rat()'],['../struct_cellular_eidrx_settings__t.html#ae9ac38b536cd30811b9759f3aca76c6a',1,'CellularEidrxSettings_t::rat()']]],
  ['recv_1',['recv',['../struct_cellular_comm_interface__t.html#a3b0c651ca2a88baaaa9d7bd9fd0e4ab5',1,'CellularCommInterface_t']]],
  ['recvtimeoutms_2',['recvTimeoutMs',['../struct_cellular_socket_context__t.html#a4dd36a5e9b741068b95be7af773a9588',1,'CellularSocketContext_t']]],
  ['remotesocketaddress_3',['remoteSocketAddress',['../struct_cellular_socket_context__t.html#af2941649e911fbd45055dfbbe371f69d',1,'CellularSocketContext_t']]],
  ['requestededrxvaue_4',['requestedEdrxVaue',['../struct_cellular_eidrx_settings__t.html#abe72396a4009c98a8c1d777ae6a77e4b',1,'CellularEidrxSettings_t']]],
  ['respcallback_5',['respCallback',['../struct_cellular_at_req__t.html#a72367139b2a234ecaf289df223244c7d',1,'CellularAtReq_t']]],
  ['rsrp_6',['rsrp',['../struct_cellular_signal_info__t.html#a56de3f4f7e62fdb2d6d249b92d638640',1,'CellularSignalInfo_t']]],
  ['rsrq_7',['rsrq',['../struct_cellular_signal_info__t.html#a1feb3d79cfe3a6b9b0a409a4694f55d0',1,'CellularSignalInfo_t']]],
  ['rssi_8',['rssi',['../struct_cellular_signal_info__t.html#ad78e64ad1b77059f577b346e937f2726',1,'CellularSignalInfo_t']]]
];
