var searchData=
[
  ['localipaddress_0',['localIpAddress',['../struct_cellular_socket_context__t.html#ae5704e11a60a710fe747fd17a53b4fe9',1,'CellularSocketContext_t']]],
  ['localport_1',['localPort',['../struct_cellular_socket_context__t.html#aba39bc30c8013db7d41a62865ca309b0',1,'CellularSocketContext_t']]]
];
