var searchData=
[
  ['firmwareversion_0',['firmwareVersion',['../struct_cellular_modem_info__t.html#a2ee0ff347ab0d617538cb6aab3dd4325',1,'CellularModemInfo_t']]]
];
