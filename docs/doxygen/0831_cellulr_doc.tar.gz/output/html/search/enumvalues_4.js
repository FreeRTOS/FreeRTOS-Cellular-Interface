var searchData=
[
  ['socketstate_5fallocated_0',['SOCKETSTATE_ALLOCATED',['../group__cellular__common__datatypes__enums.html#gga5452a7d76c6f3fe297bea080bfb18b9fadb6f0c2359e1183751b74e5aa74f68b5',1,'cellular_common.h']]],
  ['socketstate_5fconnected_1',['SOCKETSTATE_CONNECTED',['../group__cellular__common__datatypes__enums.html#gga5452a7d76c6f3fe297bea080bfb18b9fa8e58311ac8755d916ff1c788594a0ca3',1,'cellular_common.h']]],
  ['socketstate_5fconnecting_2',['SOCKETSTATE_CONNECTING',['../group__cellular__common__datatypes__enums.html#gga5452a7d76c6f3fe297bea080bfb18b9fa3fda0e54a2dd3b85fdcc156264e4d44f',1,'cellular_common.h']]],
  ['socketstate_5fdisconnected_3',['SOCKETSTATE_DISCONNECTED',['../group__cellular__common__datatypes__enums.html#gga5452a7d76c6f3fe297bea080bfb18b9fa412aaae49eeed481cc4d467215ea1114',1,'cellular_common.h']]]
];
