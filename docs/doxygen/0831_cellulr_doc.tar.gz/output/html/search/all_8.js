var searchData=
[
  ['hardwareversion_0',['hardwareVersion',['../struct_cellular_modem_info__t.html#ade38d4e966f7cc563254df4d607b42cf',1,'CellularModemInfo_t']]],
  ['hour_1',['hour',['../struct_cellular_time__t.html#ace55c1c7293cb9aa7ddabe95f61bc0bd',1,'CellularTime_t']]]
];
