var searchData=
[
  ['networkregistrationmode_0',['networkRegistrationMode',['../struct_cellular_service_status__t.html#af65efc1b00948606ff96d7faa6a60739',1,'CellularServiceStatus_t']]],
  ['nwprovidededrxvaue_1',['nwProvidedEdrxVaue',['../struct_cellular_eidrx_settings__t.html#a9de59dc0a729b3032896a4db25391bdd',1,'CellularEidrxSettings_t']]]
];
