var searchData=
[
  ['open_0',['open',['../struct_cellular_comm_interface__t.html#af5413e6ba84c706591c7ee04e94a7b17',1,'CellularCommInterface_t']]],
  ['opencallback_1',['openCallback',['../struct_cellular_socket_context__t.html#a73740e7a823925884ff049fbad82c889',1,'CellularSocketContext_t']]],
  ['operatorname_2',['operatorName',['../struct_cellular_service_status__t.html#a99a11997719b61a1e10156668050af59',1,'CellularServiceStatus_t']]],
  ['operatornameformat_3',['operatorNameFormat',['../struct_cellular_service_status__t.html#a74cb7eab60979bbce40983aacb0c2b81',1,'CellularServiceStatus_t']]]
];
