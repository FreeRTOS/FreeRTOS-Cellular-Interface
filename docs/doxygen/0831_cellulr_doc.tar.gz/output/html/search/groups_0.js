var searchData=
[
  ['cellular_20enumerated_20types_0',['Cellular Enumerated types',['../group__cellular__datatypes__enums.html',1,'']]],
  ['cellular_20function_20pointer_20types_1',['Cellular Function pointer types',['../group__cellular__datatypes__functionpointers.html',1,'']]],
  ['cellular_20handles_2',['Cellular Handles',['../group__cellular__datatypes__handles.html',1,'']]],
  ['cellular_20parameter_20structures_3',['Cellular Parameter structures',['../group__cellular__datatypes__paramstructs.html',1,'']]],
  ['cellular_5fcommon_20enumerated_20types_4',['Cellular_common Enumerated types',['../group__cellular__common__datatypes__enums.html',1,'']]],
  ['cellular_5fcommon_20function_20pointer_20types_5',['Cellular_common Function pointer types',['../group__cellular__common__datatypes__functionpointers.html',1,'']]],
  ['cellular_5fcommon_20parameter_20structures_6',['Cellular_common Parameter structures',['../group__cellular__common__datatypes__paramstructs.html',1,'']]]
];
