var searchData=
[
  ['operator_5fname_5fformat_5flong_0',['OPERATOR_NAME_FORMAT_LONG',['../group__cellular__datatypes__enums.html#ggaf3d5be5dfa6b58da9a19ce0033ad2c42ad6f0dbd2103ebd14bed5d57515de9e57',1,'cellular_types.h']]],
  ['operator_5fname_5fformat_5fmax_1',['OPERATOR_NAME_FORMAT_MAX',['../group__cellular__datatypes__enums.html#ggaf3d5be5dfa6b58da9a19ce0033ad2c42a318eff676a09e937134f07a6f42ed7da',1,'cellular_types.h']]],
  ['operator_5fname_5fformat_5fnot_5fpresent_2',['OPERATOR_NAME_FORMAT_NOT_PRESENT',['../group__cellular__datatypes__enums.html#ggaf3d5be5dfa6b58da9a19ce0033ad2c42aded7b2ae143d4831e9924efedf40c9a9',1,'cellular_types.h']]],
  ['operator_5fname_5fformat_5fnumeric_3',['OPERATOR_NAME_FORMAT_NUMERIC',['../group__cellular__datatypes__enums.html#ggaf3d5be5dfa6b58da9a19ce0033ad2c42abbd47598cb361577a0ccce377f099c8f',1,'cellular_types.h']]],
  ['operator_5fname_5fformat_5fshort_4',['OPERATOR_NAME_FORMAT_SHORT',['../group__cellular__datatypes__enums.html#ggaf3d5be5dfa6b58da9a19ce0033ad2c42a36e520e8e16c377decda1d728b4e4fc3',1,'cellular_types.h']]]
];
