var searchData=
[
  ['functions_0',['Functions',['../cellular_common_functions.html',1,'cellular_porting_module_guide'],['../cellular_functions.html',1,'(Global Namespace)']]]
];
