var group__cellular__datatypes__handles =
[
    [ "CellularHandle_t", "group__cellular__datatypes__handles.html#gaa78d4f0cb21f863efe07de19186071a6", null ],
    [ "CellularSocketHandle_t", "group__cellular__datatypes__handles.html#ga2a6b2f5ebf6684559ce5865efbdd4770", null ]
];