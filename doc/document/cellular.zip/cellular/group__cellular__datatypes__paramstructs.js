var group__cellular__datatypes__paramstructs =
[
    [ "CellularSimCardStatus_t", "structCellularSimCardStatus__t.html", [
      [ "simCardState", "structCellularSimCardStatus__t.html#aa5e00511db4829cf1e238cdabb50bd3f", null ],
      [ "simCardLockState", "structCellularSimCardStatus__t.html#ae36e0166cb6938d7f1854a979820f172", null ]
    ] ],
    [ "CellularPlmnInfo_t", "structCellularPlmnInfo__t.html", [
      [ "mcc", "structCellularPlmnInfo__t.html#af85aa377f11d2097efb01801df567001", null ],
      [ "mnc", "structCellularPlmnInfo__t.html#aecd2fb439c9395569a2ca0a09adb4b1f", null ]
    ] ],
    [ "CellularSimCardInfo_t", "structCellularSimCardInfo__t.html", [
      [ "iccid", "structCellularSimCardInfo__t.html#ab44f00f41b099fe9d6882309be4bf747", null ],
      [ "imsi", "structCellularSimCardInfo__t.html#a2263ce2d90b67c0a4ad906cc20f1247a", null ],
      [ "plmn", "structCellularSimCardInfo__t.html#aab80112c660e80585dc1ab161552197e", null ]
    ] ],
    [ "CellularModemInfo_t", "structCellularModemInfo__t.html", [
      [ "hardwareVersion", "structCellularModemInfo__t.html#ade38d4e966f7cc563254df4d607b42cf", null ],
      [ "firmwareVersion", "structCellularModemInfo__t.html#a2ee0ff347ab0d617538cb6aab3dd4325", null ],
      [ "serialNumber", "structCellularModemInfo__t.html#a59a6e1eefe318a6faafa5a1462d99112", null ],
      [ "imei", "structCellularModemInfo__t.html#a185ae2e7e09c804c7cff6c6ddf1777a0", null ],
      [ "manufactureId", "structCellularModemInfo__t.html#a21d6f8c89fcc947044f2426d2ec2418e", null ],
      [ "modelId", "structCellularModemInfo__t.html#a46a26f42af3c75e19e65377b308d5f7e", null ]
    ] ],
    [ "CellularTime_t", "structCellularTime__t.html", [
      [ "month", "structCellularTime__t.html#a8a39033276246dfda0de32aac6156be5", null ],
      [ "day", "structCellularTime__t.html#abb81ea647b9bcd0e59d5a8af7e3891ef", null ],
      [ "hour", "structCellularTime__t.html#ace55c1c7293cb9aa7ddabe95f61bc0bd", null ],
      [ "minute", "structCellularTime__t.html#a12c19b45c144f2f7d843bf30f54afeae", null ],
      [ "second", "structCellularTime__t.html#a6989fd09ce00b04ecc738bcbe46c96ee", null ],
      [ "year", "structCellularTime__t.html#ac5179e1cc8525ac56829a0d7b1301209", null ],
      [ "timeZone", "structCellularTime__t.html#acca5feafd3b070f04b1c4fbcbe82da02", null ],
      [ "dst", "structCellularTime__t.html#acbd38fe3a30dd51a34c183d6870aff33", null ]
    ] ],
    [ "CellularSignalInfo_t", "structCellularSignalInfo__t.html", [
      [ "rssi", "structCellularSignalInfo__t.html#ad78e64ad1b77059f577b346e937f2726", null ],
      [ "rsrp", "structCellularSignalInfo__t.html#a56de3f4f7e62fdb2d6d249b92d638640", null ],
      [ "rsrq", "structCellularSignalInfo__t.html#a1feb3d79cfe3a6b9b0a409a4694f55d0", null ],
      [ "sinr", "structCellularSignalInfo__t.html#aa1508f05dce506da4b3044d909bf72ac", null ],
      [ "ber", "structCellularSignalInfo__t.html#a6bd2c16188aa4065bc4bdc26a01a072c", null ],
      [ "bars", "structCellularSignalInfo__t.html#a120f7f659626a69b5335c43dbbda95e3", null ]
    ] ],
    [ "CellularServiceStatus_t", "structCellularServiceStatus__t.html", [
      [ "rat", "structCellularServiceStatus__t.html#a2d289ac8453a0b16f25a640a23a16b37", null ],
      [ "networkRegistrationMode", "structCellularServiceStatus__t.html#af65efc1b00948606ff96d7faa6a60739", null ],
      [ "csRegistrationStatus", "structCellularServiceStatus__t.html#a0839b20071dc011b428fcc19eeb9b45a", null ],
      [ "psRegistrationStatus", "structCellularServiceStatus__t.html#a8bab49bc5510bcea58cb118d4d38dce0", null ],
      [ "plmnInfo", "structCellularServiceStatus__t.html#a6774bee2b8be8390bb38a18a8ce8b1c9", null ],
      [ "operatorNameFormat", "structCellularServiceStatus__t.html#a74cb7eab60979bbce40983aacb0c2b81", null ],
      [ "operatorName", "structCellularServiceStatus__t.html#a99a11997719b61a1e10156668050af59", null ],
      [ "csRejectionType", "structCellularServiceStatus__t.html#a87e23d1c4ab5b10368792fc4480ac6a8", null ],
      [ "csRejectionCause", "structCellularServiceStatus__t.html#ae9815876e691ccc70405c7922fd58b7e", null ],
      [ "psRejectionType", "structCellularServiceStatus__t.html#a87d34a792c0780771f9db64b33380f97", null ],
      [ "psRejectionCause", "structCellularServiceStatus__t.html#ac4fc4ee9ccc0c9f42c04c2b1e209da25", null ]
    ] ],
    [ "CellularATCommandLine_t", "structCellularATCommandLine__t.html", [
      [ "pNext", "structCellularATCommandLine__t.html#a7137878408ca6595635b2c4c2639b1ac", null ],
      [ "pLine", "structCellularATCommandLine__t.html#a92a0ea252ebf8721b0951535a6e38b7e", null ]
    ] ],
    [ "CellularATCommandResponse_t", "structCellularATCommandResponse__t.html", [
      [ "status", "structCellularATCommandResponse__t.html#a7487527fa4e2d55384a7b7d9fa2ae6be", null ],
      [ "pItm", "structCellularATCommandResponse__t.html#a52c5c31279eb4477a308052ea8919c33", null ]
    ] ],
    [ "CellularPsmSettings_t", "structCellularPsmSettings__t.html", [
      [ "mode", "structCellularPsmSettings__t.html#a909b67a2f68743917d311cbf0909202d", null ],
      [ "periodicTauValue", "structCellularPsmSettings__t.html#a32873a6943420df81a1579374e1bf10b", null ],
      [ "periodicRauValue", "structCellularPsmSettings__t.html#aee65d49182ab7a3b2f2df2cd0348d021", null ],
      [ "gprsReadyTimer", "structCellularPsmSettings__t.html#a95f527ef459965d882ecb25e60716ff5", null ],
      [ "activeTimeValue", "structCellularPsmSettings__t.html#a03ad5f41a45a77b73269df3030014577", null ]
    ] ],
    [ "CellularEidrxSettings_t", "structCellularEidrxSettings__t.html", [
      [ "mode", "structCellularEidrxSettings__t.html#a0b28836d91a492d7b481002f046f9d0e", null ],
      [ "rat", "structCellularEidrxSettings__t.html#ae9ac38b536cd30811b9759f3aca76c6a", null ],
      [ "requestedEdrxVaue", "structCellularEidrxSettings__t.html#abe72396a4009c98a8c1d777ae6a77e4b", null ],
      [ "nwProvidedEdrxVaue", "structCellularEidrxSettings__t.html#a9de59dc0a729b3032896a4db25391bdd", null ],
      [ "pagingTimeWindow", "structCellularEidrxSettings__t.html#a9818e1a2a91ad8032ec2f9e354cc4c5b", null ]
    ] ],
    [ "CellularEidrxSettingsList_t", "structCellularEidrxSettingsList__t.html", [
      [ "eidrxList", "structCellularEidrxSettingsList__t.html#a7cc7457ea9a557131871b4fefb99f2d8", null ],
      [ "count", "structCellularEidrxSettingsList__t.html#ad0ceae4340e771ee54f1d320d0e38a9e", null ]
    ] ],
    [ "CellularIPAddress_t", "structCellularIPAddress__t.html", [
      [ "ipAddressType", "structCellularIPAddress__t.html#abedaa37ed58f4d9f793c0209a5be34f5", null ],
      [ "ipAddress", "structCellularIPAddress__t.html#a104fcfe5bbbf65431b4a4330e98173dd", null ]
    ] ],
    [ "CellularPdnConfig_t", "structCellularPdnConfig__t.html", [
      [ "pdnContextType", "structCellularPdnConfig__t.html#a30a72c4fdd81fb8c59f39c9c0877eb52", null ],
      [ "pdnAuthType", "structCellularPdnConfig__t.html#a5c664048e5cab733c77974b552938a09", null ],
      [ "apnName", "structCellularPdnConfig__t.html#a166fe60d7d42f4d131c26ecb9f4e89e2", null ],
      [ "username", "structCellularPdnConfig__t.html#af5b45dc449084867b3f6edb852340229", null ],
      [ "password", "structCellularPdnConfig__t.html#a4495c2a1f60408e29208e36d709223d0", null ]
    ] ],
    [ "CellularPdnStatus_t", "structCellularPdnStatus__t.html", [
      [ "contextId", "structCellularPdnStatus__t.html#ae0ad779467c3f42e1a77e869291eb15b", null ],
      [ "state", "structCellularPdnStatus__t.html#af9f77a723d7632a4c3d5198997008a83", null ],
      [ "pdnContextType", "structCellularPdnStatus__t.html#afba8208b839a06a01f7d7caab2e222d8", null ],
      [ "ipAddress", "structCellularPdnStatus__t.html#a937928c48d4e8216b27efaea5a351fd6", null ]
    ] ],
    [ "CellularSocketAddress_t", "structCellularSocketAddress__t.html", [
      [ "ipAddress", "structCellularSocketAddress__t.html#aacc25fe01367e52ffd086b01d8fe53e7", null ],
      [ "port", "structCellularSocketAddress__t.html#a59a24ad2752a49e46c55f41101ed6c69", null ]
    ] ],
    [ "CELLULAR_INVALID_SIGNAL_VALUE", "group__cellular__datatypes__paramstructs.html#ga4141e693462223e8b5749e1ce04e6bf3", null ],
    [ "CELLULAR_INVALID_SIGNAL_BAR_VALUE", "group__cellular__datatypes__paramstructs.html#ga59a8c06081c2c728d66f96bec1717590", null ]
];