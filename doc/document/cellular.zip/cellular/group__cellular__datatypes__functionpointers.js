var group__cellular__datatypes__functionpointers =
[
    [ "CellularATCommandResponseReceivedCallback_t", "group__cellular__datatypes__functionpointers.html#ga5c0c7cc1b6918b04690732f77ebd9ac9", null ],
    [ "CellularUrcNetworkRegistrationCallback_t", "group__cellular__datatypes__functionpointers.html#ga5b66e0ecf75d8f73aa8c348237d73914", null ],
    [ "CellularUrcPdnEventCallback_t", "group__cellular__datatypes__functionpointers.html#gafd8c26ee0cf3c38666c4cd2aa4eff4a2", null ],
    [ "CellularUrcSignalStrengthChangedCallback_t", "group__cellular__datatypes__functionpointers.html#ga91d271c0063ae5c0fa8b4a0c85c128dc", null ],
    [ "CellularUrcGenericCallback_t", "group__cellular__datatypes__functionpointers.html#ga47e8115ea70a6fba8d4542b03a1b986b", null ],
    [ "CellularModemEventCallback_t", "group__cellular__datatypes__functionpointers.html#gaa14536af7806c9aeb7bd825bc504d057", null ],
    [ "CellularSocketOpenCallback_t", "group__cellular__datatypes__functionpointers.html#gac21cae33f20e4a0fb2f937245bb2b511", null ],
    [ "CellularSocketDataReadyCallback_t", "group__cellular__datatypes__functionpointers.html#gab449b9bca7dc9803c66e6602d8d2f7e3", null ],
    [ "CellularSocketClosedCallback_t", "group__cellular__datatypes__functionpointers.html#gae79e5d460214b1995682287b8e93a417", null ]
];