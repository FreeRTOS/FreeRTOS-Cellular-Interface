var NAVTREE =
[
  [ "FreeRTOS Cellular Library", "index.html", [
    [ "Cellular communication interface", "comm_if.html", null ],
    [ "Cellular platform dependency", "cellular_platform.html", null ],
    [ "Configuration", "cellular_config.html", [
      [ "CELLULAR_MCC_MAX_SIZE", "cellular_config.html#CELLULAR_MCC_MAX_SIZE", null ],
      [ "CELLULAR_MNC_MAX_SIZE", "cellular_config.html#CELLULAR_MNC_MAX_SIZE", null ],
      [ "CELLULAR_ICCID_MAX_SIZE", "cellular_config.html#CELLULAR_ICCID_MAX_SIZE", null ],
      [ "CELLULAR_IMSI_MAX_SIZE", "cellular_config.html#CELLULAR_IMSI_MAX_SIZE", null ],
      [ "CELLULAR_FW_VERSION_MAX_SIZE", "cellular_config.html#CELLULAR_FW_VERSION_MAX_SIZE", null ],
      [ "CELLULAR_HW_VERSION_MAX_SIZE", "cellular_config.html#CELLULAR_HW_VERSION_MAX_SIZE", null ],
      [ "CELLULAR_SERIAL_NUM_MAX_SIZE", "cellular_config.html#CELLULAR_SERIAL_NUM_MAX_SIZE", null ],
      [ "CELLULAR_IMEI_MAX_SIZE", "cellular_config.html#CELLULAR_IMEI_MAX_SIZE", null ],
      [ "CELLULAR_NETWORK_NAME_MAX_SIZE", "cellular_config.html#CELLULAR_NETWORK_NAME_MAX_SIZE", null ],
      [ "CELLULAR_APN_MAX_SIZE", "cellular_config.html#CELLULAR_APN_MAX_SIZE", null ],
      [ "CELLULAR_PDN_USERNAME_MAX_SIZE", "cellular_config.html#CELLULAR_PDN_USERNAME_MAX_SIZE", null ],
      [ "CELLULAR_PDN_PASSWORD_MAX_SIZE", "cellular_config.html#CELLULAR_PDN_PASSWORD_MAX_SIZE", null ],
      [ "CELLULAR_IP_ADDRESS_MAX_SIZE", "cellular_config.html#CELLULAR_IP_ADDRESS_MAX_SIZE", null ],
      [ "CELLULAR_AT_CMD_MAX_SIZE", "cellular_config.html#CELLULAR_AT_CMD_MAX_SIZE", null ],
      [ "CELLULAR_NUM_SOCKET_MAX", "cellular_config.html#CELLULAR_NUM_SOCKET_MAX", null ],
      [ "CELLULAR_MANUFACTURE_ID_MAX_SIZE", "cellular_config.html#CELLULAR_MANUFACTURE_ID_MAX_SIZE", null ],
      [ "CELLULAR_MODEL_ID_MAX_SIZE", "cellular_config.html#CELLULAR_MODEL_ID_MAX_SIZE", null ],
      [ "CELLULAR_EDRX_LIST_MAX_SIZE", "cellular_config.html#CELLULAR_EDRX_LIST_MAX_SIZE", null ],
      [ "CELLULAR_PDN_CONTEXT_ID_MIN", "cellular_config.html#CELLULAR_PDN_CONTEXT_ID_MIN", null ],
      [ "CELLULAR_PDN_CONTEXT_ID_MAX", "cellular_config.html#CELLULAR_PDN_CONTEXT_ID_MAX", null ],
      [ "CELLULAR_MAX_RAT_PRIORITY_COUNT", "cellular_config.html#CELLULAR_MAX_RAT_PRIORITY_COUNT", null ],
      [ "CELLULAR_MAX_SEND_DATA_LEN", "cellular_config.html#CELLULAR_MAX_SEND_DATA_LEN", null ],
      [ "CELLULAR_MAX_RECV_DATA_LEN", "cellular_config.html#CELLULAR_MAX_RECV_DATA_LEN", null ],
      [ "CELLULAR_SUPPORT_GETHOSTBYNAME", "cellular_config.html#CELLULAR_SUPPORT_GETHOSTBYNAME", null ],
      [ "CELLULAR_COMM_IF_SEND_TIMEOUT_MS", "cellular_config.html#CELLULAR_COMM_IF_SEND_TIMEOUT_MS", null ],
      [ "CELLULAR_COMM_IF_RECV_TIMEOUT_MS", "cellular_config.html#CELLULAR_COMM_IF_RECV_TIMEOUT_MS", null ],
      [ "CELLULAR_CONFIG_STATIC_ALLOCATION_CONTEXT", "cellular_config.html#CELLULAR_CONFIG_STATIC_ALLOCATION_CONTEXT", null ],
      [ "CELLULAR_CONFIG_STATIC_ALLOCATION_COMM_CONTEXT", "cellular_config.html#CELLULAR_CONFIG_STATIC_ALLOCATION_COMM_CONTEXT", null ],
      [ "CELLULAR_CONFIG_DEFAULT_RAT", "cellular_config.html#CELLULAR_CONFIG_DEFAULT_RAT", null ]
    ] ],
    [ "Functions", "cellular_functions.html", null ],
    [ "Data types", "modules.html", "modules" ],
    [ "Files", "files.html", "files" ]
  ] ]
];

var NAVTREEINDEX =
[
"cellular__api_8h.html",
"group__cellular__datatypes__enums.html#gga389b56c510a0ce521ce6ce8866e77c55aedaa1b55b8871b75d7f4cf8dc47e685a",
"structCellularServiceStatus__t.html#a87e23d1c4ab5b10368792fc4480ac6a8"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';