var structCellularCommInterface__t =
[
    [ "open", "structCellularCommInterface__t.html#af5413e6ba84c706591c7ee04e94a7b17", null ],
    [ "send", "structCellularCommInterface__t.html#a695354e1be93901de855fcfd405130ae", null ],
    [ "recv", "structCellularCommInterface__t.html#a3b0c651ca2a88baaaa9d7bd9fd0e4ab5", null ],
    [ "close", "structCellularCommInterface__t.html#ad6aa698a3c69c3d219d856db1e57c228", null ]
];