var cellular__comm__interface_8h =
[
    [ "CellularCommInterface_t", "structCellularCommInterface__t.html", "structCellularCommInterface__t" ],
    [ "CellularCommInterfaceHandle_t", "cellular__comm__interface_8h.html#ad6cd00eb743d56280131f8d9145b6635", null ],
    [ "CellularCommInterfaceReceiveCallback_t", "cellular__comm__interface_8h.html#a82721c6ea18230852b6eb9daf29ae392", null ],
    [ "CellularCommInterfaceOpen_t", "cellular__comm__interface_8h.html#a35de749e306a95c0ab225560ac7032a0", null ],
    [ "CellularCommInterfaceSend_t", "cellular__comm__interface_8h.html#a7a3be93d8e30114ee9f9053bd0281e38", null ],
    [ "CellularCommInterfaceRecv_t", "cellular__comm__interface_8h.html#ae61433cb4c41fbb43e76807cb0193bb5", null ],
    [ "CellularCommInterfaceClose_t", "cellular__comm__interface_8h.html#a6da32ee844b899f16b728dc32d322a82", null ],
    [ "CellularCommInterfaceError_t", "cellular__comm__interface_8h.html#ad21a587c554ac2c66c7d66574043472e", [
      [ "IOT_COMM_INTERFACE_SUCCESS", "cellular__comm__interface_8h.html#ad21a587c554ac2c66c7d66574043472ea01b2bf1a7d67f95d06f5519340c8d432", null ],
      [ "IOT_COMM_INTERFACE_FAILURE", "cellular__comm__interface_8h.html#ad21a587c554ac2c66c7d66574043472ea47797bb8a7784821d03924a30a3c7e25", null ],
      [ "IOT_COMM_INTERFACE_BAD_PARAMETER", "cellular__comm__interface_8h.html#ad21a587c554ac2c66c7d66574043472ea3bd773c0fe591df0c9a6a85b94c67d6d", null ],
      [ "IOT_COMM_INTERFACE_NO_MEMORY", "cellular__comm__interface_8h.html#ad21a587c554ac2c66c7d66574043472ea09124664e795d7f88841a22d65e66504", null ],
      [ "IOT_COMM_INTERFACE_TIMEOUT", "cellular__comm__interface_8h.html#ad21a587c554ac2c66c7d66574043472eabd5b592a959c6fd5be94a56ed1d88b37", null ],
      [ "IOT_COMM_INTERFACE_DRIVER_ERROR", "cellular__comm__interface_8h.html#ad21a587c554ac2c66c7d66574043472ea80c730cd5a7754f795b72cf699f362bc", null ],
      [ "IOT_COMM_INTERFACE_BUSY", "cellular__comm__interface_8h.html#ad21a587c554ac2c66c7d66574043472eaeca6a1fd4306a1e5282cebcef85e3277", null ]
    ] ]
];