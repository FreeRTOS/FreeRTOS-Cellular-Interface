var NAVTREE =
[
  [ "FreeRTOS Cellular Common Library", "index.html", [
    [ "Porting cellular module", "porting_cellular_module.html", "porting_cellular_module" ],
    [ "Functions", "cellular_common_functions.html", null ],
    [ "Data types", "modules.html", "modules" ],
    [ "Files", "files.html", "files" ]
  ] ]
];

var NAVTREEINDEX =
[
"cellular__at__core_8h.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';