var group__cellular__common__datatypes__functionpointers =
[
    [ "CellularAtParseTokenHandler_t", "group__cellular__common__datatypes__functionpointers.html#ga7d5f79b6ffe818da204451d667fadbd8", null ],
    [ "CellularATCommandDataPrefixCallback_t", "group__cellular__common__datatypes__functionpointers.html#ga828f4f9f0c663cffa653fe01d0d6f009", null ],
    [ "CellularATCommandDataSendPrefixCallback_t", "group__cellular__common__datatypes__functionpointers.html#ga45846e857cd862e6387a7e20927c9b04", null ]
];