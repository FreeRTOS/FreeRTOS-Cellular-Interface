var group__cellular__common__datatypes__paramstructs =
[
    [ "CellularAtReq_t", "structCellularAtReq__t.html", [
      [ "pAtCmd", "structCellularAtReq__t.html#a78daaea1eb323c2e788003c009d504ec", null ],
      [ "atCmdType", "structCellularAtReq__t.html#a2aeb0ea37a6746a2c4b73660716b6423", null ],
      [ "pAtRspPrefix", "structCellularAtReq__t.html#ac312650455dc906bacd0795578860591", null ],
      [ "respCallback", "structCellularAtReq__t.html#a72367139b2a234ecaf289df223244c7d", null ],
      [ "pData", "structCellularAtReq__t.html#abc4ae9d3ea15040c79fe8fea960f8cf0", null ],
      [ "dataLen", "structCellularAtReq__t.html#aaf49a8b7ada73cca6618a71be6fd4ea5", null ]
    ] ],
    [ "CellularAtDataReq_t", "structCellularAtDataReq__t.html", [
      [ "pData", "structCellularAtDataReq__t.html#a410fec7ac962fd6c98eff0f76a5c104a", null ],
      [ "dataLen", "structCellularAtDataReq__t.html#a96f6945df2a1764084e5b8d6f065654c", null ],
      [ "pSentDataLength", "structCellularAtDataReq__t.html#a2e7f7c417c9e5fa5aaa8fe8046a4cd73", null ],
      [ "pEndPattern", "structCellularAtDataReq__t.html#ac8b1e457e6e8b0846013b60472098ca1", null ],
      [ "endPatternLen", "structCellularAtDataReq__t.html#ac76c2a8fdb726a9cf402decea3a2107d", null ]
    ] ],
    [ "CellularAtParseTokenMap_t", "structCellularAtParseTokenMap__t.html", [
      [ "pStrValue", "structCellularAtParseTokenMap__t.html#a1ff0f0741d686d320accfab892b63623", null ],
      [ "parserFunc", "structCellularAtParseTokenMap__t.html#a86ed2448ea66d09fe27bdd08b2940798", null ]
    ] ],
    [ "CellularSocketContext_t", "structCellularSocketContext__t.html", [
      [ "contextId", "structCellularSocketContext__t.html#aac523065b94c9e4140f6e7555a54438d", null ],
      [ "socketId", "structCellularSocketContext__t.html#a6f05ae7bf8110bf0183f4303dcc5520d", null ],
      [ "socketState", "structCellularSocketContext__t.html#ac79a634a46ea79903e24a80bbd117075", null ],
      [ "socketType", "structCellularSocketContext__t.html#a22dc063f6505be86edbe2ee3f25f2a87", null ],
      [ "socketDomain", "structCellularSocketContext__t.html#a9fc5d568b18b8d74ede134040ca8d132", null ],
      [ "socketProtocol", "structCellularSocketContext__t.html#ad2b91a7e33e2dedafee89add7e1fe1ba", null ],
      [ "localIpAddress", "structCellularSocketContext__t.html#ae5704e11a60a710fe747fd17a53b4fe9", null ],
      [ "localPort", "structCellularSocketContext__t.html#aba39bc30c8013db7d41a62865ca309b0", null ],
      [ "dataMode", "structCellularSocketContext__t.html#a8293b82cb491875420a8477f75200aef", null ],
      [ "sendTimeoutMs", "structCellularSocketContext__t.html#a74b7b7d17299c44ab0926c76bc0c1e14", null ],
      [ "recvTimeoutMs", "structCellularSocketContext__t.html#a4dd36a5e9b741068b95be7af773a9588", null ],
      [ "remoteSocketAddress", "structCellularSocketContext__t.html#af2941649e911fbd45055dfbbe371f69d", null ],
      [ "dataReadyCallback", "structCellularSocketContext__t.html#a18ff2d5b31108942fa3234101dce9da8", null ],
      [ "pDataReadyCallbackContext", "structCellularSocketContext__t.html#aebe3d8b8e56ff2ab4b6b89a39af7cda9", null ],
      [ "openCallback", "structCellularSocketContext__t.html#a73740e7a823925884ff049fbad82c889", null ],
      [ "pOpenCallbackContext", "structCellularSocketContext__t.html#ac66008a4d4a37fa7e2d0c0d6dcd0690d", null ],
      [ "closedCallback", "structCellularSocketContext__t.html#abad9d60861ee81a48cb0093a36290558", null ],
      [ "pClosedCallbackContext", "structCellularSocketContext__t.html#ab88a308e2f7c8d181ed9fe1e622498ed", null ],
      [ "pModemData", "structCellularSocketContext__t.html#aff1aa3affda1c42912533127beda1d63", null ]
    ] ],
    [ "CellularTokenTable_t", "structCellularTokenTable__t.html", [
      [ "pCellularUrcHandlerTable", "structCellularTokenTable__t.html#a478085a6a0a03103e981682d3eace986", null ],
      [ "cellularPrefixToParserMapSize", "structCellularTokenTable__t.html#a8830849fb19a562da497f71e0b8136f5", null ],
      [ "pCellularSrcTokenErrorTable", "structCellularTokenTable__t.html#ada0e4e53923e52c07738e58a430376cc", null ],
      [ "cellularSrcTokenErrorTableSize", "structCellularTokenTable__t.html#a23fc0f804ae16eb670f8fd7a559e65f1", null ],
      [ "pCellularSrcTokenSuccessTable", "structCellularTokenTable__t.html#ac4353497c33823d28fd5bd5a871a06ee", null ],
      [ "cellularSrcTokenSuccessTableSize", "structCellularTokenTable__t.html#ad878b89414daefb2a3653cc3ac502aca", null ],
      [ "pCellularUrcTokenWoPrefixTable", "structCellularTokenTable__t.html#a3e4b73326ec6ac61e5891c60bef0914e", null ],
      [ "cellularUrcTokenWoPrefixTableSize", "structCellularTokenTable__t.html#a6472ffee2e213e3bd1b2e6065ac1f2df", null ],
      [ "pCellularSrcExtraTokenSuccessTable", "structCellularTokenTable__t.html#a93c94ab9326198ade445dcff73fe9adb", null ],
      [ "cellularSrcExtraTokenSuccessTableSize", "structCellularTokenTable__t.html#a3cc01c60dba0c69e496ade6f6805256f", null ]
    ] ]
];